// declare module '*.js' {
//     const content: any;
//     export default content;
//   }