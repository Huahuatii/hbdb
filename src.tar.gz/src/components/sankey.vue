<template>
    <div style="width:1380px;margin:0 auto">
        <div class="echart-div" style="width: 1280px; margin: 25px;height: 700px; overflow-y:scroll ;">
            <echarts_sankey />
        </div>
    </div>
</template>

<script lang="ts" setup>
import echarts_sankey from '../home/echarts_sankey.vue';
</script>