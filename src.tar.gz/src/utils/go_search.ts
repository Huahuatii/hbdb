// 这个不怎么用了
import router from '@/router';
export const go_search_CPM = () => {
    return router.push('/search/cpm')
}

export const go_search_MM = () => {
    return router.push('/search/mm')
}

export const go_search_MD = () => {
    return router.push('/search/md')
}

export const go_search_T = () => {
    return router.push('/search/t')
}

export const go_search_CC = () => {
    return router.push('/search/cc')
}