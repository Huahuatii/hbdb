<!-- <template>
<el-pagination
v-model:currentPage="data.searchParams.pagenum"
v-model:page-size="data.searchParams.pagesize"
:page-sizes="[5, 10, 25, 50]"
background=True
layout="total, sizes, prev, pager, next, jumper"
:total="data.total"
@size-change="searchCPM" 
@current-change="searchCPM"
/>
</template> -->