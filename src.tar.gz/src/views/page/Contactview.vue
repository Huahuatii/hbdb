<template>
  <div class="about">
    <div class="bc1">


      <!-- 创建一个div，其中包含两个div -->
      <div style="display: flex;justify-content: space-between;">
        <!-- 左侧div -->
        <div style="width: 720px; margin: 25px;min-height: 400px;  display: inline-block;">
          <h1 style="padding-bottom:0px;color: #803c0b;"> <strong>Zhejiang University</strong></h1>
        <h4 style="padding-bottom:40px;color: #803c0b;">INNOVATION INSTITUTE FOR ARTIFICIAL INTELLIGENCE IN MEDICINE</h4>
        
        <!-- <h5>Affiliated institutions: School of Pharmacy, Zhejiang University, Institute of Intelligent Innovative Drugs, Zhejiang University</h5> -->
        <!-- 4 / F, Building 6, Dadanggu, -->
        <h3>Address:</h3>
          <p>Hangzhou, Zhejiang 310018, China</p>
          <p> No. 291, Fucheng Road, Xiasha Street, Qiantang District</p>
        
        <h3 style="padding-top: 30px;"> <strong>Contact information:</strong></h3>
        <!-- <svg t="1661685030647" class="icon" viewBox="0 0 1024 1024" version="1.1" xmlns="http://www.w3.org/2000/svg"
          p-id="2657" style="width:20px;height:20px">
          <path
            d="M887.044 267.194H135.36c-39.56 0-71.631 32.07-71.631 71.632v463.536c0 39.561 32.07 71.632 71.631 71.632h751.685c39.561 0 71.632-32.07 71.632-71.632V338.826c0-39.562-32.07-71.632-71.632-71.632z m12.733 100.255v406.715c0 0.039-0.003 0.077-0.003 0.116L683.68 580.338l216.097-212.89zM383.103 620.616c70.996 50.776 191.38 54.63 258.105 0.748L857.07 815.095H166.406l216.697-194.48z m471.412-294.523l-218.34 215.055c-77.786 80.175-179.434 75.4-252.906-1.627L171.962 326.093h682.553z m-731.889 40.932c0-2.023 0.153-4.01 0.436-5.953l216.892 219.127-217.3 195.023c-0.01-0.353-0.027-0.704-0.027-1.058V367.025z"
            p-id="2658"></path>
        </svg>： -->
        <p>22260236@zju.edu.cn
        </p>
        <p>(+86)13819114329
        </p>
        </div>
        <!-- 右侧div -->
        <div style="width: 500px; margin: 25px;min-height: 400px;  display: inline-block;">

          <iframe
            src="https://ditu.amap.com/search?query=%E6%B5%99%E6%B1%9F%E5%A4%A7%E5%AD%A6%E6%99%BA%E8%83%BD%E5%88%9B%E6%96%B0%E8%8D%AF%E7%89%A9%E7%A0%94%E7%A9%B6%E9%99%A2&city=330100&geoobj=120.328078%7C30.33014%7C120.337212%7C30.33417&zoom=18.29"
            width="100%" height="500" frameborder="0" style="border:0;" class="rounded"></iframe>
   
        </div>

      </div>
      <div >

        

        
      </div>


    </div>
  </div>
</template>
  



<style scoped>
.bc1 {
  background-color: rgb(245, 242, 236);
  width: 1350px;
  min-height: 100px;
  margin: 0 auto;
  margin-top: 30px;
  border-radius: 0.9ch;
  padding: 5px 15px;
}
</style>