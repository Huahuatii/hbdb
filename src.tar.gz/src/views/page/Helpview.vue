<template>

  <el-divider>TEST</el-divider>
  <Test />
  <el-divider>TABLES</el-divider>
  <MANYTABLES />
  <el-divider>关系图</el-divider>
  <div class="ggplot111"><test_echarts/></div>
  <el-divider>桑基图</el-divider>
  <div class="ggplot111" style="padding-left: 75px;width: 1125px;"><sankey/></div>

  
</template>
  

<script lang="ts" setup>

import Test from '/home/hht/Myapps/Vue_demo/Vue_vite_demo2/hbdb/src/components/Test.vue'
import MANYTABLES from '/home/hht/Myapps/Vue_demo/Vue_vite_demo2/hbdb/src/components/many_table.vue'
import test_echarts from '/home/hht/Myapps/Vue_demo/Vue_vite_demo2/hbdb/src/views/home/test_echarts.vue'
import sankey from '/home/hht/Myapps/Vue_demo/Vue_vite_demo2/hbdb/src/views/home/echarts_sankey.vue'
</script>

<style scoped>
.ggplot111{
  width: 1200px;
  margin: 0 auto;
  background-color: rgb(255, 255, 255);
  min-height: 800px;
}
</style>