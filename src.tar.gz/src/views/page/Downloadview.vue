<template>
  <el-divider>桑基图</el-divider>
  <div class="ggplot111"><sankey/></div>

  
</template>
  

<script lang="ts" setup>


import sankey from '/home/hht/Myapps/Vue_demo/Vue_vite_demo2/hbdb/src/views/home/echarts_sankey.vue'
</script>

<style scoped>
.ggplot111{
  width: 1200px;
  margin: 0 auto;
  background-color: azure;
  min-height: 800px;
}
</style>